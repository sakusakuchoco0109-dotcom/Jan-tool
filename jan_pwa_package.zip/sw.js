/* JAN PWA Service Worker */
const CACHE_NAME = "jan-pwa-v1";
const APP_ASSETS = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./sw.js",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

// Install: pre-cache app shell
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_ASSETS))
  );
  self.skipWaiting();
});

// Activate: cleanup old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.map((k) => (k === CACHE_NAME ? null : caches.delete(k))))
    )
  );
  self.clients.claim();
});

// Fetch: cache-first for app shell, plus runtime caching for ZXing CDN
self.addEventListener("fetch", (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Only handle GET
  if (req.method !== "GET") return;

  // Runtime cache ZXing from unpkg
  const isZXing = url.hostname === "unpkg.com" && url.pathname.includes("@zxing/library");
  if (isZXing) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cached = await cache.match(req);
        if (cached) return cached;
        try {
          const fresh = await fetch(req);
          cache.put(req, fresh.clone());
          return fresh;
        } catch (e) {
          return cached || Response.error();
        }
      })
    );
    return;
  }

  // App shell: cache-first
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((fresh) => {
        // cache same-origin navigations/assets
        if (url.origin === self.location.origin) {
          caches.open(CACHE_NAME).then((cache) => cache.put(req, fresh.clone()));
        }
        return fresh;
      }).catch(() => {
        // Offline fallback: try index.html for navigations
        if (req.mode === "navigate") return caches.match("./index.html");
        throw new Error("offline");
      });
    })
  );
});
